
#include "pseudomode_solver.h"
#include <cassert>
#include <iostream>
int main() {
    using namespace PseudomodeFramework;
    SystemParams sys;
    sys.omega0_eV = 0.01;
    sys.temperature_K = 300.0;
    sys.n_max = 3;
    sys.coupling = "sigma_z";

    SimulationConfig cfg;
    cfg.dt_ps = 0.01;
    cfg.t_final_ps = 0.1;

    PseudomodeFramework2D fw(cfg);
    std::vector<double> omega(100);
    for(size_t i=0;i<omega.size();++i) omega[i]=1e-3*i;
    std::vector<double> times(10);
    for(size_t i=0;i<times.size();++i) times[i]=0.01*i;

    auto res = fw.simulate_material("graphene", sys, omega, times);
    std::cout << "Status: " << res.status << "\n";
    return 0;
}
